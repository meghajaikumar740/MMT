package com.mmt;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.xml.LaunchSuite.ExistingSuite;

public class MMTMethods {
	WebDriver webdriver;
	WebDriverWait wait2;
	JavascriptExecutor jse;
	Actions ac2;
	
	MMTMethods(WebDriver driver){
	webdriver = driver;
	}
	
	public void login() throws InterruptedException {
	//	wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ch_login_icon']/span[2]")));
		webdriver.findElement(By.xpath("//*[@id='ch_login_icon']/span[2]")).click();
	
	}
	public void enterCredentials(String uname, String pass) throws InterruptedException{
		String uname2 = uname;
		String pass2 = pass;
		jse = (JavascriptExecutor) webdriver;
		jse.executeScript("document.getElementById('ch_login_email').value = 'meghajaikumar740@gmail.com';");
		jse.executeScript("document.getElementById('ch_login_password').value = 'alphaOMEGA';");
		Thread.sleep(200);
			
	}
	public void login2(){
		webdriver.findElement(By.xpath("//*[@id='ch_login_btn'] ")).click();
	}
	
	public void selectTrip(){
		//Book Round trip	
		webdriver.findElement(By.xpath("//*[contains(text(),'round trip')]")).click();
	}
	
	public void selectSource(String text1, String text2){
		String place1 = text1;
		String place2 = text2;
		//Select source	
		webdriver.findElement(By.xpath("//label[@for='switch__input_2']")).click();
		webdriver.findElement(By.xpath("//*[@id='hp-widget__sfrom']")).clear();
		webdriver.findElement(By.xpath("//*[@id='hp-widget__sfrom']")).sendKeys(place1);
		webdriver.findElement(By.xpath("//*[contains(text(), '"+place2+"')]")).click();
	}
	
	public void selectDestination(String text1, String text2){
		String place1 = text1;
		String place2 = text2;
		//Select destination	
		webdriver.findElement(By.xpath("//*[@id='hp-widget__sTo']")).click();
		webdriver.findElement(By.xpath("//*[@id='hp-widget__sTo']")).clear();
		webdriver.findElement(By.xpath("//*[@id='hp-widget__sTo']")).sendKeys(place1);
		webdriver.findElement(By.xpath("//ul[@id='ui-id-2']/li[@aria-label='Top Cities : Kolkata, India ']/div/p[1]/span[@class='autoCompleteItem__label' and contains(text(), '"+place2+"')]")).click();	
	}
	
	public void selectDepartDate(int dd, int mm, int yyyy){
		int date = dd;
		int month = mm - 1;
		int year = yyyy;
		
		//Select departure date
		webdriver.findElement(By.xpath("//*[@id='hp-widget__depart']")).click();
		
	//	while (webdriver.findElement(By.xpath("//td[@data-month='"+month+"' and  @data-year='"+year+"' ]/a[contains(text(), '"+date+"')]")).isDisplayed()==false){
	//		System.out.println("O");
	//		webdriver.findElement(By.xpath("//div[@class='dateFilter hasDatepicker']/div/div[@class='ui-datepicker-group ui-datepicker-group-last']/div/a[@title='Next']")).click();
	//	}	

		webdriver.findElement(By.xpath("//td[@data-month='"+month+"' and  @data-year='"+year+"' ]/a[contains(text(), '"+date+"')]")).click();
	}
	
	public void selectReturnDate(int dd, int mm, int yyyy){
		int date = dd;
		int month = mm - 1;
		int year = yyyy;
		
		//Select return date
		webdriver.findElement(By.xpath("//*[@id='hp-widget__return']")).click();
		
	//	while (webdriver.findElement(By.xpath("//div[contains(@class,'dateFilterReturn')]//td[@data-month='"+month+"' and  @data-year='"+year+"' ]/a[@class='ui-state-default' and contains(text(), '"+date+"')]")).isDisplayed()==false){
	//		webdriver.findElement(By.xpath("//div[@class='dateFilterReturn hasDatepicker']/div/div[@class='ui-datepicker-group ui-datepicker-group-last']/div/a/span")).click();
	//	}
		
		webdriver.findElement(By.xpath("//div[contains(@class,'dateFilterReturn')]//td[@data-month='"+month+"' and  @data-year='"+year+"' ]/a[@class='ui-state-default' and contains(text(), '"+date+"')]")).click();
	}
	
	public void selectTravelClass(String travelClass)
	{
		String travel = travelClass;

		webdriver.findElement(By.xpath("//div[@class='inputM visited pax_count pot']/input[@id='hp-widget__paxCounter_pot']")).click();
		
		//Selecting travel class
		switch (travel){
			case "E":
				webdriver.findElement(By.xpath("//*[@id='pot_class']/ul/li/span[@id='economy']")).click();
				break;
			case "PE":
				webdriver.findElement(By.xpath("//*[@id='pot_class']/ul/li/span[@id='premiumEconomy']")).click();
				break;
			case "B":
				webdriver.findElement(By.xpath("//*[@id='pot_class']/ul/li/span[@id='business']")).click();
				break;
			default:
				webdriver.findElement(By.xpath("//*[@id='pot_class']/ul/li/span[@id='economy']")).click();
		}
	}
	
	public void selectPax(int a, int c, int i){
		int adults = a;
		int children = c;
		int infants = i;
		
		//Selecting no. of passengers
		webdriver.findElement(By.xpath("//*[@class='pull-left pax-counter-container']/div[@class='paxCounter']//ul[@class='adult_counter']/li[contains(text(),'"+adults+"')]")).click();
		webdriver.findElement(By.xpath("//*[@class='pull-left pax-counter-container']/div[@class='paxCounter' and @id='flight_children']//ul[@class='child_counter']/li[contains(text(),'"+children+"')]")).click();
		webdriver.findElement(By.xpath("//*[@class='pull-left pax-counter-container']/div[@class='paxCounter' and @id='flight_infant']//ul[@class='infant_counter']/li[contains(text(),'"+infants+"')]")).click();
				
		webdriver.findElement(By.xpath("//*[@id='pot_class']/a")).click();
	}
	
	public void searchFlights(){
		webdriver.findElement(By.xpath("//*[@id='searchBtn']")).click();
		wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='content']/div/div[3]/div[1]/div[1]/div/div[1]/div/div[2]/a")));
	}
	
	public void book(){
		System.out.println("P");
//		webdriver.findElement(By.xpath("//span/span/a[@class='btn btn-lg pull-right btn-primary-red']")).click();
		wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='sticky_bottom']")));
		webdriver.findElement(By.xpath("//*[@id='content']/div/div[4]/div[1]/div[1]/div[3]/div[3]/div/div[2]/span/span/a")).click();

	}
}
