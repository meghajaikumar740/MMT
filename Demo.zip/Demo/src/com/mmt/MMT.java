package com.mmt;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MMT{
	WebDriver driver = new ChromeDriver();
	WebDriverWait wait; // =new WebDriverWait(driver, 60);
	Actions ac;
	JavascriptExecutor jse;
	MMTMethods object = new MMTMethods(driver);
	
	@BeforeClass
	public void beforeclass() {
		String path = System.getProperty("user.dir");
		String chromePath = path + "/chromedriver.exe";
		System.setProperty("WebDriver.Chrome.driver", chromePath);
		
// launch application		
		driver.get("https://www.makemytrip.com/");
		wait =new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ch_login_icon']/span[2]")));
		driver.manage().window().maximize();
			
	} 
	
	@BeforeMethod
	public void beforemethod() {
		System.out.println("beforemethod");
		
	}
	
/*	@Test(priority =0)
	public void launchMMT() {
		
	}	*/
	
	@Test(priority =0)
	public void login() throws InterruptedException {
	
		object.login();
		object.enterCredentials("meghajaikumar740@gmail.com", "alphaOMEGA");
		object.login2();

/*		Actions ac = new Actions(driver);
		ac.moveByOffset(300, 100).build().perform(); */
		
	}
	
	@Test(priority =1)
	public void roundTrip() throws InterruptedException {

		object.selectTrip();
		
		object.selectSource("Pune","Pune, India");

		object.selectDestination("Kolkata","Kolkata, India");

		object.selectDepartDate(11,12,2018);
		
		object.selectReturnDate(29,12,2018);
		
		object.selectTravelClass("B");
		
		object.selectPax(3,2,2);
		
		object.searchFlights();
		
	}
	
	@Test(priority =2)
	public void selectFlights() throws InterruptedException{
		
		object.book();
	}
	
	
	@AfterMethod
	public void aftermethod() {
		System.out.println("aftermethod");
		
	}
	
	
	@AfterTest
	public void afterTest() {
		System.out.println("after class");
	}
	
	

}
